function [filtered_values]= filter_Micro (values)
% Filter for microphone values

%filtered_values  = filter_TP_A(values);
filtered_values  = values;