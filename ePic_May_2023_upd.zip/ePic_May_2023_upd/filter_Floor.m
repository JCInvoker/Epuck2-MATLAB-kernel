function [filtered_values]= filter_Floor (values)
% Filter for Flore sensor values

filtered_values  = values;